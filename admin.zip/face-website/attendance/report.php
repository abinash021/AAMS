<?php
$pageTitle = "Attendance Report";
require_once '../includes/header.php';

// Check if user is logged in and is a teacher or admin
if (!isLoggedIn() || (!isTeacher() && !isAdmin())) {
    setFlashMessage('You do not have permission to access that page.', 'danger');
    redirect(BASE_URL . '/login.php');
}

// Initialize classes
$academic = new Academic();
$attendance = new Attendance();
$student = new Student();

// Process delete request
if (isPostRequest() && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $csrfToken = getPostField('csrf_token');
    $attendanceId = getPostField('attendance_id');
    
    // Validate CSRF token
    if (!validateCsrfToken($csrfToken)) {
        setFlashMessage('Invalid form submission. Please try again.', 'danger');
    } elseif (empty($attendanceId)) {
        setFlashMessage('No attendance record specified for deletion.', 'danger');
    } else {
        // Check if attendance is from today
        $db = Database::getInstance();
        $attendanceData = $db->getRow(
            "SELECT date FROM attendance WHERE id = :id",
            [':id' => $attendanceId]
        );
        
        if ($attendanceData && $attendanceData['date'] === date('Y-m-d')) {
            $result = $attendance->delete($attendanceId);
            
            if ($result) {
                setFlashMessage('Attendance record deleted successfully.', 'success');
            } else {
                setFlashMessage('Failed to delete attendance record.', 'danger');
            }
        } else {
            setFlashMessage('You can only delete attendance records for the current date.', 'warning');
        }
    }
    
    redirect($_SERVER['REQUEST_URI']);
}

// Get classes taught by the teacher or all classes for admin
$teacherClasses = isAdmin() ? $academic->getAllClasses() : $academic->getClassesByTeacher(getCurrentUserId());

// Check if any classes exist
if (empty($teacherClasses)) {
    setFlashMessage('No classes available in the system.', 'warning');
    redirect(BASE_URL . '/'. (isAdmin() ? 'admin' : 'teacher') .'/dashboard.php');
}

// Get selected class, date range, and student filter
$classId = getQueryParam('class_id', $teacherClasses[0]['id'] ?? null);
$date = getQueryParam('date', date('Y-m-d'));
$fromDate = getQueryParam('from_date', '');
$toDate = getQueryParam('to_date', '');
$studentId = getQueryParam('student_id', '');

// Check if a valid class is selected
$selectedClass = null;
foreach ($teacherClasses as $class) {
    if ($class['id'] == $classId) {
        $selectedClass = $class;
        break;
    }
}

// If no valid class selected, use the first one
if (!$selectedClass && !empty($teacherClasses)) {
    $selectedClass = $teacherClasses[0];
    $classId = $selectedClass['id'];
}

// Get attendance for the selected class and date/date range
$attendanceRecords = [];
if ($selectedClass) {
    if (!empty($fromDate) && !empty($toDate)) {
        // Date range query
        $attendanceRecords = $attendance->getForClassDateRange($selectedClass['id'], $fromDate, $toDate, $studentId);
    } else {
        // Single date query
        $attendanceRecords = $attendance->getForClass($selectedClass['id'], $date, $studentId);
    }
}

// Get all students for the selected class for student filter dropdown
$allStudents = [];
if ($selectedClass) {
    $allStudents = $student->getBySemester($selectedClass['semester_id']);
}

// Calculate statistics
$presentCount = 0;
$absentCount = 0;

foreach ($attendanceRecords as $record) {
    if ($record['status'] === 'present') {
        $presentCount++;
    } else {
        $absentCount++;
    }
}

$totalStudents = count($attendanceRecords);
$attendancePercentage = ($totalStudents > 0) ? round(($presentCount / $totalStudents) * 100, 2) : 0;
$isToday = (empty($fromDate) && empty($toDate) && $date === date('Y-m-d'));
?>

<div class="row mb-4">
    <div class="col-md-12">
        <h2><i class="bi bi-file-earmark-text"></i> Attendance Report</h2>
        <p class="text-muted">View and manage attendance records for classes.</p>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-funnel"></i> Filter Attendance</h5>
            </div>
            <div class="card-body">
                <form method="get" class="row g-3">
                    <div class="col-md-4">
                        <label for="class_id" class="form-label">Class</label>
                        <select name="class_id" id="class_id" class="form-select">
                            <?php foreach ($teacherClasses as $class): ?>
                                <option value="<?php echo $class['id']; ?>" <?php echo ($classId == $class['id']) ? 'selected' : ''; ?>>
                                    <?php echo $class['name']; ?> (<?php echo $class['semester_name']; ?> - <?php echo $class['branch_name']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="student_id" class="form-label">Filter by Student</label>
                        <select name="student_id" id="student_id" class="form-select">
                            <option value="">All Students</option>
                            <?php foreach ($allStudents as $studentRecord): ?>
                                <option value="<?php echo $studentRecord['id']; ?>" <?php echo ($studentId == $studentRecord['id']) ? 'selected' : ''; ?>>
                                    <?php echo $studentRecord['roll_number']; ?> - <?php echo $studentRecord['name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="date" class="form-label">Single Date</label>
                        <input type="date" class="form-control" id="date" name="date" value="<?php echo $date; ?>">
                    </div>
                    <div class="col-md-1">
                        <label class="form-label">OR</label>
                        <div class="text-center mt-2">
                            <strong>OR</strong>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <label for="from_date" class="form-label">From Date</label>
                        <input type="date" class="form-control" id="from_date" name="from_date" value="<?php echo $fromDate; ?>">
                    </div>
                    <div class="col-md-2">
                        <label for="to_date" class="form-label">To Date</label>
                        <input type="date" class="form-control" id="to_date" name="to_date" value="<?php echo $toDate; ?>">
                    </div>
                    <div class="col-md-6 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">
                            <i class="bi bi-filter"></i> Apply Filter
                        </button>
                        <?php if (count($attendanceRecords) > 0): ?>
                        <button type="button" class="btn btn-success" onclick="printReport()">
                            <i class="bi bi-printer"></i> Print
                        </button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="bi bi-clipboard-data"></i> 
                    <?php echo $selectedClass ? $selectedClass['name'] : 'No Class Selected'; ?> 
                    - <?php 
                        if (!empty($fromDate) && !empty($toDate)) {
                            echo formatDate($fromDate) . ' to ' . formatDate($toDate);
                        } else {
                            echo formatDate($date);
                        }
                    ?>
                    <?php if (!empty($studentId)): ?>
                        <?php 
                            foreach ($allStudents as $studentRecord) {
                                if ($studentRecord['id'] == $studentId) {
                                    echo ' - ' . $studentRecord['name'];
                                    break;
                                }
                            }
                        ?>
                    <?php endif; ?>
                </h5>
                <div>
                    <?php if ($isToday): ?>
                        <a href="<?php echo BASE_URL; ?>/attendance/mark.php?class_id=<?php echo $selectedClass['id']; ?>" class="btn btn-sm btn-outline-primary me-2">
                            <i class="bi bi-camera"></i> Mark Attendance
                        </a>
                        <a href="<?php echo BASE_URL; ?>/attendance/manual.php?class_id=<?php echo $selectedClass['id']; ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-pencil"></i> Manual Entry
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-3 text-center">
                        <div class="py-3">
                            <h3><?php echo $totalStudents; ?></h3>
                            <p class="text-muted mb-0">Total Students</p>
                        </div>
                    </div>
                    <div class="col-md-3 text-center">
                        <div class="py-3">
                            <h3 class="text-success"><?php echo $presentCount; ?></h3>
                            <p class="text-muted mb-0">Present</p>
                        </div>
                    </div>
                    <div class="col-md-3 text-center">
                        <div class="py-3">
                            <h3 class="text-danger"><?php echo $absentCount; ?></h3>
                            <p class="text-muted mb-0">Absent</p>
                        </div>
                    </div>
                    <div class="col-md-3 text-center">
                        <div class="py-3">
                            <h3 class="<?php echo ($attendancePercentage >= 75) ? 'text-success' : 'text-warning'; ?>">
                                <?php echo $attendancePercentage; ?>%
                            </h3>
                            <p class="text-muted mb-0">Attendance Rate</p>
                        </div>
                    </div>
                </div>
                
                <?php if (count($attendanceRecords) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Roll Number</th>
                                    <th>Student Name</th>
                                    <?php if (!empty($fromDate) && !empty($toDate)): ?>
                                    <th>Date</th>
                                    <?php endif; ?>
                                    <th>Time</th>
                                    <th>Status</th>
                                    <th>Marked By</th>
                                    <?php if ($isToday && (isTeacher() || isAdmin())): ?>
                                    <th>Actions</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $count = 1; ?>
                                <?php foreach ($attendanceRecords as $record): ?>
                                    <tr>
                                        <td><?php echo $count++; ?></td>
                                        <td><?php echo $record['roll_number']; ?></td>
                                        <td><?php echo $record['student_name']; ?></td>
                                        <?php if (!empty($fromDate) && !empty($toDate)): ?>
                                        <td><?php echo formatDate($record['date']); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo formatTime($record['time']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo ($record['status'] == 'present') ? 'success' : 'danger'; ?>">
                                                <?php echo ucfirst($record['status']); ?>
                                            </span>
                                            <?php if (isset($record['confidence_score'])): ?>
                                                <small class="ms-2 text-muted">
                                                    <i class="bi bi-bar-chart-fill"></i> <?php echo round($record['confidence_score'], 2); ?>%
                                                </small>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo $record['teacher_name']; ?></td>
                                        <?php if ($isToday && (isTeacher() || isAdmin())): ?>
                                        <td>
                                            <form method="post" class="delete-form" onsubmit="return confirm('Are you sure you want to delete this attendance record?');">
                                                <?php echo csrfField(); ?>
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="attendance_id" value="<?php echo $record['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <i class="bi bi-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> No attendance records found for the selected date.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
// Add extra JavaScript
$extraJs = <<<EOT
<script>
    // Initialize when the page loads
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-submit on class change
        document.getElementById('class_id').addEventListener('change', function() {
            this.form.submit();
        });
        
        // Clear single date when date range is used
        document.getElementById('from_date').addEventListener('change', function() {
            if (this.value) {
                document.getElementById('date').value = '';
            }
        });
        
        document.getElementById('to_date').addEventListener('change', function() {
            if (this.value) {
                document.getElementById('date').value = '';
            }
        });
        
        // Clear date range when single date is used
        document.getElementById('date').addEventListener('change', function() {
            if (this.value) {
                document.getElementById('from_date').value = '';
                document.getElementById('to_date').value = '';
            }
        });
    });
    
    function printReport() {
        // Create a new window for printing
        var printWindow = window.open('', '_blank');
        var printContent = generatePrintContent();
        
        printWindow.document.write(printContent);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    }
    
    function generatePrintContent() {
        var className = '<?php echo $selectedClass ? $selectedClass['name'] : 'No Class Selected'; ?>';
        var dateRange = '<?php 
            if (!empty($fromDate) && !empty($toDate)) {
                echo formatDate($fromDate) . ' to ' . formatDate($toDate);
            } else {
                echo formatDate($date);
            }
        ?>';
        var studentFilter = '<?php 
            if (!empty($studentId)) {
                foreach ($allStudents as $studentRecord) {
                    if ($studentRecord['id'] == $studentId) {
                        echo $studentRecord['name'];
                        break;
                    }
                }
            } else {
                echo 'All Students';
            }
        ?>';
        
        var html = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Attendance Report</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .header { text-align: center; margin-bottom: 30px; }
                .info { margin-bottom: 20px; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                .stats { display: flex; justify-content: space-around; margin: 20px 0; }
                .stat-box { text-align: center; }
                @media print { body { margin: 0; } }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Face Recognition Attendance System</h1>
                <h2>Attendance Report</h2>
            </div>
            <div class="info">
                <p><strong>Class:</strong> ${className}</p>
                <p><strong>Date:</strong> ${dateRange}</p>
                <p><strong>Student Filter:</strong> ${studentFilter}</p>
                <p><strong>Generated on:</strong> ${new Date().toLocaleString()}</p>
            </div>
            <div class="stats">
                <div class="stat-box">
                    <h3><?php echo $totalStudents; ?></h3>
                    <p>Total Records</p>
                </div>
                <div class="stat-box">
                    <h3><?php echo $presentCount; ?></h3>
                    <p>Present</p>
                </div>
                <div class="stat-box">
                    <h3><?php echo $absentCount; ?></h3>
                    <p>Absent</p>
                </div>
                <div class="stat-box">
                    <h3><?php echo $attendancePercentage; ?>%</h3>
                    <p>Attendance Rate</p>
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Roll Number</th>
                        <th>Student Name</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Marked By</th>
                    </tr>
                </thead>
                <tbody>`;
        
        <?php $count = 1; ?>
        <?php foreach ($attendanceRecords as $record): ?>
        html += `
                    <tr>
                        <td><?php echo $count++; ?></td>
                        <td><?php echo $record['roll_number']; ?></td>
                        <td><?php echo $record['student_name']; ?></td>
                        <td><?php echo formatDate($record['date']); ?></td>
                        <td><?php echo formatTime($record['time']); ?></td>
                        <td><?php echo ucfirst($record['status']); ?></td>
                        <td><?php echo $record['teacher_name']; ?></td>
                    </tr>`;
        <?php endforeach; ?>
        
        html += `
                </tbody>
            </table>
        </body>
        </html>`;
        
        return html;
    }
</script>
EOT;
?>

<?php require_once '../includes/footer.php'; ?> 